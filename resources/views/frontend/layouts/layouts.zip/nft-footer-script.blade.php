<!-- Javascript -->
<script src="{{ URL::asset('assets/nft/js/main.js') }}"></script>
<script src="{{ URL::asset('assets/nft/js/jquery.easing.js') }}"></script>
<script src="{{ URL::asset('assets/nft/js/popper.min.js') }}"></script>
<script src="{{ URL::asset('assets/nft/js/bootstrap.min.js') }}"></script>
<script src="{{ URL::asset('assets/nft/js/wow.min.js') }}"></script>
<script src="{{ URL::asset('assets/nft/js/plugin.js') }}"></script>
<script src="{{ URL::asset('assets/nft/js/count-down.js') }}"></script>
<script src="{{ URL::asset('assets/nft/js/shortcodes.js') }}"></script>
<script src="{{ URL::asset('assets/nft/js/swiper-bundle.min.js') }}"></script>
<script src="{{ URL::asset('assets/nft/js/price-ranger.js')}}"></script>
<script src="{{ URL::asset('assets/nft/js/swiper.js') }}"></script>
<script src="{{ URL::asset('assets/nft/js/moralis.js') }}"></script>
<script src="{{ URL::asset('assets/nft/js/nft.js') }}"></script>

@yield('script')
@yield('script_bottom')